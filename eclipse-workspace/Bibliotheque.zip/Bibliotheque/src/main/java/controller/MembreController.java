package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.Membre;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

import dao.MembreDAO;

@WebServlet("/membres")
public class MembreController extends HttpServlet {
    private static final long serialVersionUID = 1L;
	private MembreDAO membreDAO;

    @Override
    public void init() {
        membreDAO = new MembreDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "delete":
                int id = Integer.parseInt(request.getParameter("id"));
                membreDAO.supprimerMembre(id);
                response.sendRedirect("membres");
                break;
            case "list":
            default:
                List<Membre> membres = membreDAO.listerMembres();
                request.setAttribute("membres", membres);
                request.getRequestDispatcher("/view/membres.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String nom = request.getParameter("nom");
        String prenom = request.getParameter("prenom");
        String email = request.getParameter("email");
        String telephone = request.getParameter("telephone");

        Membre membre = new Membre();
        membre.setNom(nom);
        membre.setPrenom(prenom);
        membre.setEmail(email);
        membre.setTelephone(telephone);
        membre.setStatut("Actif");

        membreDAO.ajouterMembre(membre);
        response.sendRedirect("membres");
    }
}