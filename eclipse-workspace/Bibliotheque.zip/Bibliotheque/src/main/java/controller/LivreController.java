package controller;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import model.Livre;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

import dao.LivreDAO;

@WebServlet("/livres")
public class LivreController extends HttpServlet {
    private static final long serialVersionUID = 1L;
	private LivreDAO livreDAO;

    @Override
    public void init() {
        livreDAO = new LivreDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action == null) action = "list";

        switch (action) {
            case "delete":
                int id = Integer.parseInt(request.getParameter("id"));
                livreDAO.supprimerLivre(id);
                response.sendRedirect("livres");
                break;
            case "list":
            default:
                List<Livre> livres = livreDAO.listerLivres();
                request.setAttribute("livres", livres);
                request.getRequestDispatcher("/view/livres.jsp").forward(request, response);
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String titre = request.getParameter("titre");
        String auteur = request.getParameter("auteur");
        String isbn = request.getParameter("isbn");

        Livre livre = new Livre();
        livre.setTitre(titre);
        livre.setAuteur(auteur);
        livre.setIsbn(isbn);
        livre.setStatutDisponibilite("Disponible");

        livreDAO.ajouterLivre(livre);
        response.sendRedirect("livres");
    }
}