package controller;

import dao.EmpruntDao;
import jakarta.servlet.annotation.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Emprunt;

import java.io.IOException;
import java.sql.Date;

@WebServlet("/emprunts")
public class EmpruntController extends HttpServlet {
    private static final long serialVersionUID = 1L;
	private EmpruntDao dao = new EmpruntDao();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("ajouter".equals(action)) {
            int idLivre = Integer.parseInt(request.getParameter("idLivre"));
            int idMembre = Integer.parseInt(request.getParameter("idMembre"));
            Date dateEmprunt = Date.valueOf(request.getParameter("dateEmprunt"));
            Date dateRetourPrevue = Date.valueOf(request.getParameter("dateRetourPrevue"));

            Emprunt e = new Emprunt();
            e.setIdLivre(idLivre);
            e.setIdMembre(idMembre);
            e.setDateEmprunt(dateEmprunt);
            e.setDateRetourPrevue(dateRetourPrevue);

            boolean success = dao.ajouterEmprunt(e);
            if (success) response.sendRedirect("/view/emprunts.jsp");
            else response.getWriter().println("Erreur : livre non disponible ou limite atteinte.");
        }

        if ("retour".equals(action)) {
            int idEmprunt = Integer.parseInt(request.getParameter("idEmprunt"));
            Date dateRetourEffective = Date.valueOf(request.getParameter("dateRetourEffective"));
            boolean success = dao.retourLivre(idEmprunt, dateRetourEffective);
            if (success) response.sendRedirect("emprunts");
            else response.getWriter().println("Erreur lors du retour du livre.");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setAttribute("emprunts", dao.getEmpruntsEnCours());
        request.getRequestDispatcher("/view/emprunts.jsp").forward(request, response);
    }
}
