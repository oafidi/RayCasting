package dao;

import java.sql.*;
import java.util.*;

import model.Membre;

public class MembreDAO {

    public void ajouterMembre(Membre membre) {
        String sql = "INSERT INTO Membre (nom, prenom, email, telephone, date_inscription, statut) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, membre.getNom());
            ps.setString(2, membre.getPrenom());
            ps.setString(3, membre.getEmail());
            ps.setString(4, membre.getTelephone());
            ps.setDate(5, membre.getDateInscription());
            ps.setString(6, membre.getStatut());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Membre> listerMembres() {
        List<Membre> membres = new ArrayList<>();
        String sql = "SELECT * FROM Membre";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Membre membre = new Membre(
                    rs.getInt("id_membre"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("email"),
                    rs.getString("telephone"),
                    rs.getDate("date_inscription"),
                    rs.getString("statut")
                );
                membres.add(membre);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return membres;
    }

    public void supprimerMembre(int id) {
        String sql = "DELETE FROM Membre WHERE id_membre = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
