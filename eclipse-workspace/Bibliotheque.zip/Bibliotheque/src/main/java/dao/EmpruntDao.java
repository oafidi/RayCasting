package dao;

import model.Emprunt;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpruntDao {

    // Ajouter un emprunt
    public boolean ajouterEmprunt(Emprunt e) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);  // Démarre une transaction

            // Vérifications
            if (!isLivreDisponible(conn, e.getIdLivre())) {
                conn.rollback();
                return false;
            }

            if (nombreEmpruntsEnCours(conn, e.getIdMembre()) >= 3) {
                conn.rollback();
                return false;
            }

            // Insertion de l'emprunt
            String sql = "INSERT INTO Emprunt(id_livre, id_membre, date_emprunt, date_retour_prevue, statut) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                pst.setInt(1, e.getIdLivre());
                pst.setInt(2, e.getIdMembre());
                pst.setDate(3, e.getDateEmprunt());
                pst.setDate(4, e.getDateRetourPrevue());
                pst.setString(5, "en cours");
                pst.executeUpdate();
            }

            // Mise à jour du statut du livre
            setLivreDisponibilite(conn, e.getIdLivre(), "emprunté");

            conn.commit();  // Valide la transaction
            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();  // Annule tout en cas d'erreur
                } catch (SQLException e2) {
                    e2.printStackTrace();
                }
            }
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);  // Restaure le mode par défaut
                    conn.close();  // ✅ Ferme la connexion
                } catch (SQLException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }

    // Retour d'un livre - CORRIGÉ
    public boolean retourLivre(int idEmprunt, Date dateRetourEffective) {
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);  // Démarre une transaction

            // 1. Récupérer l'id du livre
            int idLivre = 0;
            String sqlSelect = "SELECT id_livre FROM Emprunt WHERE id_emprunt = ?";
            try (PreparedStatement pstSelect = conn.prepareStatement(sqlSelect)) {
                pstSelect.setInt(1, idEmprunt);
                try (ResultSet rs = pstSelect.executeQuery()) {
                    if (rs.next()) {
                        idLivre = rs.getInt("id_livre");
                    } else {
                        conn.rollback();
                        return false;  // Emprunt introuvable
                    }
                }
            }

            // 2. Mettre à jour l'emprunt
            String sqlUpdate = "UPDATE Emprunt SET date_retour_effective = ?, statut = ? WHERE id_emprunt = ?";
            try (PreparedStatement pstUpdate = conn.prepareStatement(sqlUpdate)) {
                pstUpdate.setDate(1, dateRetourEffective);
                pstUpdate.setString(2, "retourné");
                pstUpdate.setInt(3, idEmprunt);
                pstUpdate.executeUpdate();
            }

            // 3. Mettre à jour le livre (MÊME CONNEXION)
            setLivreDisponibilite(conn, idLivre, "disponible");

            conn.commit();  // Valide la transaction
            return true;

        } catch (SQLException ex) {
            ex.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e2) {
                    e2.printStackTrace();
                }
            }
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();  // ✅ Ferme la connexion
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // Lister tous les emprunts en cours
    public List<String> getEmpruntsEnCours() {
        List<String> emprunts = new ArrayList<>();
        String sql = "SELECT e.id_emprunt, l.titre, m.nom, m.prenom, e.date_emprunt, e.date_retour_prevue " +
                     "FROM Emprunt e " +
                     "JOIN Livre l ON e.id_livre = l.id_livre " +
                     "JOIN Membre m ON e.id_membre = m.id_membre " +
                     "WHERE e.statut='en cours'";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                String info = "Emprunt #" + rs.getInt("id_emprunt") + 
                              " - Livre: " + rs.getString("titre") +
                              " - Membre: " + rs.getString("nom") + " " + rs.getString("prenom") +
                              " - Date emprunt: " + rs.getDate("date_emprunt") +
                              " - Date retour prévue: " + rs.getDate("date_retour_prevue");
                emprunts.add(info);
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return emprunts;
    }

    // ✅ Version qui RÉUTILISE une connexion existante
    private boolean isLivreDisponible(Connection conn, int idLivre) throws SQLException {
        String sql = "SELECT statut_disponibilite FROM Livre WHERE id_livre=?";
    	System.out.print("hello omar"+idLivre);
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, idLivre);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                	System.out.print("hello chama");
                    return rs.getString("statut_disponibilite").equals("disponible");
                }
            }
        }
        return false;
    }

    // ✅ Version qui RÉUTILISE une connexion existante
    private void setLivreDisponibilite(Connection conn, int idLivre, String statut) throws SQLException {
        String sql = "UPDATE Livre SET statut_disponibilite=? WHERE id_livre=?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, statut);
            pst.setInt(2, idLivre);
            pst.executeUpdate();
        }
    }

    // ✅ Version qui RÉUTILISE une connexion existante
    private int nombreEmpruntsEnCours(Connection conn, int idMembre) throws SQLException {
        String sql = "SELECT COUNT(*) as nbr FROM Emprunt WHERE id_membre=? AND statut='en cours'";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, idMembre);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("nbr");
                }
            }
        }
        return 0;
    }
}