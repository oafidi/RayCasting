package dao;

import java.sql.*;
import java.util.*;

import model.Livre;

public class LivreDAO {

    public void ajouterLivre(Livre livre) {
        String sql = "INSERT INTO Livre (titre, auteur, isbn, statut_disponibilite, date_ajout) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, livre.getTitre());
            ps.setString(2, livre.getAuteur());
            ps.setString(3, livre.getIsbn());
            ps.setString(4, livre.getStatutDisponibilite());
            ps.setDate(5, livre.getDateAjout());
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Livre> listerLivres() {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT * FROM Livre";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Livre livre = new Livre(
                    rs.getInt("id_livre"),
                    rs.getString("titre"),
                    rs.getString("auteur"),
                    rs.getString("isbn"),
                    rs.getString("statut_disponibilite"),
                    rs.getDate("date_ajout")
                );
                livres.add(livre);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return livres;
    }

    public void supprimerLivre(int id) {
        String sql = "DELETE FROM Livre WHERE id_livre = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}